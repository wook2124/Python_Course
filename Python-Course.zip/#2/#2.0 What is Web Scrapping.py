# 다른 곳에서 url 같은걸 가져오면 
# 미리보기 이미지 혹은 글(기사제목 등)을 보여주는 것임
https://en.wikipedia.org/wiki/Web_scraping