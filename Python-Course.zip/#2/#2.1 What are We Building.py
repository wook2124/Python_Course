# Python과 관련된 일자리를 엑셀시트로 옮기기 대작전!
https://stackoverflow.com/jobs?q=python
https://www.indeed.com/jobs?q=python&limit=50