# list  
days = ["Mon","Tue","Wed","Thur","Fri","Sat","Sun"]

print(days)
days.append("Break time")
days.reverse()
days.remove("Mon")
print(days)