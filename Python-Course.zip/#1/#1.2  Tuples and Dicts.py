# tuple 
days = ("Mon","Tue","Wed","Thur","Fri","Sat","Sun")

print(type(days))


# dictionary
wook = {
  "name" : "Wook",
  "age" : 27,
  "korean" : True,
  "fav_food" : ["Kimchi",   "Chicken"]
}

print(wook)
wook["Man"] = True
print(wook)