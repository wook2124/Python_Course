# str, int, float, bool, none 
a_string = "like this"
a_number = 3
a_float = 3.12
a_boolean = False
a_none = None

print(type(a_none)) 