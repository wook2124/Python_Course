# 니꼴라스쌤 💖
I just wanted to say: Thank you for being here and watching our lectures.

See you on the next video!