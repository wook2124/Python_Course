# print와 len 같이쓰기
print(len("zxcvasdfqwertyuighjkbnolp"))


# str을 int(정수)로 바꾸기
age = "27"
print(type(age))

n_age = int(age)
print(n_age)
print(type(n_age))