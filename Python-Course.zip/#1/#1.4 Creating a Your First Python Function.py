# def(define 정의하기, 함수만들기)
def say_hello():
  print("hello")
  print("bye")

# say_hello는 버튼 / ()는 누르기 
say_hello()