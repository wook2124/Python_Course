# Python_Course
Nomad Coders's Python Course

It's started since 2020.01.27.~

https://github.com/wook2124/requests

https://www.crummy.com/software/BeautifulSoup/bs4/doc/

https://docs.python.org/3/library/stdtypes.html#sequence-types-list-tuple-range

https://stackoverflow.com/jobs?q=python

https://www.indeed.com/jobs?q=python&limit=50