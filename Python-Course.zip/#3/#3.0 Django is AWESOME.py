# Django 사이트
https://www.djangoproject.com/


# Documentation(문서)만 보고도 웹사이트를 구축할 수 있음!
# ko 언어도 지원됨!
https://docs.djangoproject.com/ko/3.0/